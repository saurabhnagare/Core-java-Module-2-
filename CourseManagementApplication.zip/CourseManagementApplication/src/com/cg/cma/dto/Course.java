package com.cg.cma.dto;

public class Course {
	private long courseId;
	private String courseTitle;
	private double fees;
	private int duration;
	public Course() {
		// TODO Auto-generated constructor stub
	}
	
		public long getCourseId() {
		return courseId;
	}

	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}

		public String getCourseTitle() {
		return courseTitle;
	}
	public void setCourseTitle(String courseTitle) {
		this.courseTitle = courseTitle;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	public Course(long courseId, String courseTitle, double fees, int duration) {
		super();
		this.courseId = courseId;
		this.courseTitle = courseTitle;
		this.fees = fees;
		this.duration = duration;
	}

	@Override
	public String toString() {
		return "Course [course_id=" + courseId + ", courseTitle=" + courseTitle + ", fees=" + fees + ", duration="
				+ duration + "]";
	}
}
