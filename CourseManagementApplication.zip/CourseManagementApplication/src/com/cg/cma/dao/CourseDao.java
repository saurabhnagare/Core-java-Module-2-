package com.cg.cma.dao;

import java.util.List;

import com.cg.cma.dto.Course;
import com.cg.cma.exceptions.CourseException;

public interface CourseDao {
	long insertCourse(Course course) throws CourseException;
	List<Course> getAllCourses() throws CourseException;
	boolean updateCourse(Course course) throws CourseException;
	boolean deleteCourse(long courseid) throws CourseException;
}
