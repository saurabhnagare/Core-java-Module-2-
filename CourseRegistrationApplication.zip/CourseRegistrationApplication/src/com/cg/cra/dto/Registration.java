package com.cg.cra.dto;

import java.time.LocalDate;

public class Registration {
	private long regId;
	private String studentName;
	private String address;
	private String phoneNo;
	private LocalDate regDate;
	private long courseId;
	public Registration() {
		// TODO Auto-generated constructor stub
	}
	public long getRegId() {
		return regId;
	}
	public void setRegId(long regId) {
		this.regId = regId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public LocalDate getRegDate() {
		return regDate;
	}
	public void setRegDate(LocalDate regDate) {
		this.regDate = regDate;
	}
	public long getCourseId() {
		return courseId;
	}
	public void setCourseId(long courseId) {
		this.courseId = courseId;
	}
	@Override
	public String toString() {
		return "Registration [regId=" + regId + ", studentName=" + studentName + ", address=" + address + ", phoneNo="
				+ phoneNo + ", regDate=" + regDate + ", courseId=" + courseId + "]";
	}
	public Registration(long regId, String studentName, String address, String phoneNo, LocalDate regDate,
			long courseId) {
		super();
		this.regId = regId;
		this.studentName = studentName;
		this.address = address;
		this.phoneNo = phoneNo;
		this.regDate = regDate;
		this.courseId = courseId;
	}
	
}
