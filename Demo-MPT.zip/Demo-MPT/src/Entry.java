import java.util.Date;
import java.util.Scanner;

import com.capgemini.dao.EmployeeDAO;
import com.capgemini.dao.EmployeeDAOImpl;
import com.capgemini.dao.OrderDAO;
import com.capgemini.dao.OrderDAOImpl;
import com.capgemini.dto.EmployeeDTO;
import com.capgemini.dto.OrderDTO;

public class Entry {

	
	public static void main(String[] args) {
		
		// Order
		OrderDAO daoRef = new OrderDAOImpl();
		
		
		OrderDTO order = new OrderDTO();
		order.setOrderDate(new Date());
	//	order.setOrderID(1);
		
		daoRef.createOrder(order);
		

//		OrderDTO order = daoRef.findById(1);
		
//		System.out.println(order.getOrderID() + "/" + order.getOrderDate());   */
		
		// Employee

	/*	
		String name=null;
		int id=0;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the name of Employee: ");
    	name = sc.next();
		
		
		EmployeeDAO daoRef = new EmployeeDAOImpl();
		
		EmployeeDTO emp = new EmployeeDTO(); 
	//	emp.setId();
		emp.setName(name);
		emp.setDoj(new Date());
		
		daoRef.createEmployee(emp);  
		
	    System.out.println("Enter the ID of Employee to search: ");
	    id = sc.nextInt();
		
		EmployeeDTO emp1 = daoRef.findById(id);
		
		System.out.println("ID: "+emp1.getId() + " Name: " + emp1.getName()+" DOJ: "+ emp1.getDoj()); 
		
		
		*/
		
		
		
		
	}
	
}
