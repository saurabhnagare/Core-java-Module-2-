package com.capgemini.dao;

import com.capgemini.dto.EmployeeDTO;

public interface EmployeeDAO {

	public boolean createEmployee(EmployeeDTO emp);
	public EmployeeDTO findById(int id);
}
