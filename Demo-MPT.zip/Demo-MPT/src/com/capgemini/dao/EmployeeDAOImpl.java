package com.capgemini.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.dto.EmployeeDTO;

import com.capgemini.utils.DBUtils;
import com.capgemini.utils.Log4jHTMLLayout;

public class EmployeeDAOImpl implements EmployeeDAO{
	private static Logger log = Logger.getLogger(Log4jHTMLLayout.class);
private Connection dbConnection;	// ???
	
	{
		
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	@Override
	public boolean createEmployee(EmployeeDTO emp) {
		String insertQuery = "insert into employeedetails values (?,?,?)";
	
		try {
			PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
			
	//		insertStatement.setInt(1, emp.getId());
			insertStatement.setInt(1, generateNextEmployeeId());
			insertStatement.setString(2, emp.getName());
			Date dojDate = new Date(emp.getDoj().getTime());
			
            insertStatement.setDate(3, dojDate);

			
			int rows = insertStatement.executeUpdate();
			
			if(rows > 0)
			{	
				System.out.println("Record inserted successfully.");
				log.info("Added a row in db now...");
				return true;
			}
			else
			{
				System.out.println("Failed to insert record!");
			}
				return false;
		} catch (SQLException e) {
			e.printStackTrace();
			log.error(e.getMessage());
			return false;
		}
	}
	
	private int generateNextEmployeeId() throws SQLException
	{
		int id=0;
		String selectQuery="select emp_id__seq.nextval from dual";
		
		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);
		
		result.next();
		id = result.getInt(1);
		return id;
	}
	
	@Override
	public EmployeeDTO findById(int id) {

		String selectQuery = "select * from EmployeeDetails where id = ?";
		
		try {
			PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);
					
			selectStatement.setInt(1, id);
			
			ResultSet result = selectStatement.executeQuery();
			
			while(result.next()){
				
				int empId = result.getInt(1);
				String name = result.getString(2);
				Date empDateSQL =  result.getDate(3);
				
				java.util.Date empDate = new java.util.Date(empDateSQL.getTime());
				
				EmployeeDTO emp = new EmployeeDTO();
				emp.setId(empId);
				emp.setName(name);
				emp.setDoj(empDate);
				
				return emp;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
