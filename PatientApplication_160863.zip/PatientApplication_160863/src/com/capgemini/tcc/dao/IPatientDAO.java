package com.capgemini.tcc.dao;

import com.capgemini.exception.PatientsException;
import com.capgemini.tcc.bean.PatientBean;

public interface IPatientDAO {
	int addPatientDetails(PatientBean patient) throws PatientsException;
	PatientBean getPatientDetails(int patientId) throws PatientsException;
}
