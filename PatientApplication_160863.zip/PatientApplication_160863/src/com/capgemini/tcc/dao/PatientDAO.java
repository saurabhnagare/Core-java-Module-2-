package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.dao.QueryMapper;
import com.capgemini.exception.PatientsException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.util.DBConnection;

public class PatientDAO implements IPatientDAO{
Logger logger=Logger.getRootLogger();
	
	public PatientDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	@SuppressWarnings("resource")
	public int addPatientDetails(PatientBean patient) throws PatientsException
	{
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		int patient_id=0;
		
		int queryResult=0;
		try
		{	
			
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
			preparedStatement.setString(1, patient.getName());
			preparedStatement.setString(2, patient.getAge());
			preparedStatement.setString(3, patient.getPhoneNumber());
			preparedStatement.setString(4, patient.getDescription());
				
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.PATIENTID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				patient_id=resultSet.getInt(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				System.out.println("Failed inserting patient details");
				
			}
			else
			{
				logger.info("Patient details added successfully:");
				return patient_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new PatientsException("Tehnical problem occured refer log",sqlException);
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (Exception e) 
			{
				e.printStackTrace();
				logger.error(e.getMessage());
				throw new PatientsException("Error in closing db connection",e);

			}
		}
		
		return 0;
	}
		
	
	public PatientBean getPatientDetails(int patientId) throws PatientsException
	{
Connection connection = DBConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet result = null;

		
		try {
			preparedStatement=connection.prepareStatement(QueryMapper.FIND_PATIENT_BY_ID);
					
		
			preparedStatement.setInt(1, patientId);
			int queryResult=0;
			queryResult=preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.PATIENTID_QUERY_SEQUENCE);
			result=preparedStatement.executeQuery();

//			ResultSet result = PreparedStatement.executeQuery();
			
			while(result.next()){
				
				int patient_Id = result.getInt(1);
				String patient_name = result.getString(2);
				String age = result.getString(3);
				String phone = result.getString(4);
				String description = result.getString(5);
				Date patientDateSQL =  result.getDate(3);
				
				java.util.Date consultationDate = new java.util.Date(patientDateSQL.getTime());
				
				PatientBean patient = new PatientBean();
				patient.setId(patient_Id);
				patient.setName(patient_name);
				patient.setAge(age);
				patient.setPhoneNumber(phone);
				patient.setDescription(description);
				patient.setConsultationDate(consultationDate);
				
				
				return patient;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}
	
}
