package com.capgemini.tcc.ui;

import java.util.Date;
import java.util.InputMismatchException;
import com.capgemini.tcc.service.IPatientService;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.capgemini.exception.PatientsException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.service.PatientService;

public class Client {
	static Scanner sc = new Scanner(System.in);
	static PatientDAO patientdao = null;
	static PatientService patientService = null;
	static IPatientService ipatientService = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws PatientsException {
		PropertyConfigurator.configure("resources//log4j.properties");
		PatientBean patientbean = null;

		int patient_id;
		int patientid;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Patient Application ");
			System.out.println("_______________________________\n");

			System.out.println("1.Add Patient Information");
			System.out.println("2.Search Patient By ID");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (patientbean  == null) {
						try {
							patientbean   = populatePatientbean ();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 System.out.println(patientbean);
					}

					try {
						patientService = new PatientService();
						patient_id = patientService.addPatientDetails(patientbean);

						System.out.println("Patient details  has been successfully registered ");
						System.out.println("Patient  ID Is: " + patient_id);

					} catch (Exception e) {
						e.printStackTrace();
						logger.error("exception occured", e);
						System.out.println("ERROR : "
								+ e.getMessage());
						throw new PatientsException("Failed to add patient",e);
						
					} 

					break;

				case 2:
					try {
						 System.out.println("Enter the ID of Patient to search: ");
						    patientid = sc.nextInt();
						
					
						patientdao = new PatientDAO();
						PatientBean patientbean1=  patientdao.getPatientDetails(patientid);
					//    patientbean.toString();

					    System.out.println("PatientID: "+patientbean1.getId() + " Name: " + patientbean1.getName()+"Age: "+patientbean1.getAge()+"Description: "+ patientbean1.getDescription()+"Phone Number: "+ patientbean1.getPhoneNumber()+" Consultation Date: "+ patientbean1.getConsultationDate()); 
						

					} catch (Exception e) {
						e.printStackTrace();
						logger.error("exception occured", e);
						System.out.println("ERROR : "
								+ e.getMessage());
						throw new PatientsException("Failed to add patient",e);
						
					} 
					
				case 3:

					System.out.print("Exit Patient Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
		}

		}// end of while
	}

	private static PatientBean populatePatientbean() throws PatientsException {

		/*
		     private int id;
    private String name;
	private String age;
	private String phoneNumber;
	private String description;
	private Date consultationDate;
		  
		 */
		PatientBean patientbean = new PatientBean();

		System.out.println("\n Patient Details");

		System.out.println("Enter  name: ");
		patientbean.setName(sc.next());
		System.out.println("Enter age: ");
		patientbean.setAge(sc.next());
		System.out.println("Enter phone: ");
		patientbean.setPhoneNumber(sc.next());
		System.out.println("Enter Description: ");
		patientbean.setDescription(sc.next());
		
	
		
        PatientService patientService = new PatientService();
//System.out.println("After creating patient service impl object");

		try {
			patientService.validatePatient(patientbean);
			
			System.out.println("after validate patient");
			return patientbean ;
		} catch (Exception e) {
			e.printStackTrace();
			logger.error("exception occured", e);
			System.err.println("Invalid data:");
			System.err.println(e.getMessage() + " \n Try again..");
			
			System.exit(0);
			

		}
		return null;

	}
}
